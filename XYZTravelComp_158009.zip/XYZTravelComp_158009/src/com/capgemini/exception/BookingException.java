package com.capgemini.exception;

public class BookingException extends Exception {
String msg;
	public BookingException(String msg)
	{
		super(msg);

	}
	public BookingException(String msg,Throwable cause,Error code)
	{
		//super (msg,cause,code);

	}

}
