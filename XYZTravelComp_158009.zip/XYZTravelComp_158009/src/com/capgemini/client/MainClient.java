package com.capgemini.client;

public class MainClient {

}
